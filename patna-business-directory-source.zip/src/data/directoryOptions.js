export const CATEGORIES = [
  { name: 'Restaurants & Cafes', hindi: 'रेस्टोरेंट और कैफे', icon: 'Utensils', color: 'bg-orange-50 text-orange-700' },
  { name: 'Healthcare', hindi: 'स्वास्थ्य सेवाएँ', icon: 'HeartPulse', color: 'bg-rose-50 text-rose-700' },
  { name: 'Education', hindi: 'शिक्षा', icon: 'GraduationCap', color: 'bg-indigo-50 text-indigo-700' },
  { name: 'Home Services', hindi: 'होम सर्विस', icon: 'House', color: 'bg-amber-50 text-amber-700' },
  { name: 'Shopping', hindi: 'शॉपिंग', icon: 'ShoppingBag', color: 'bg-pink-50 text-pink-700' },
  { name: 'Automobile', hindi: 'ऑटोमोबाइल', icon: 'CarFront', color: 'bg-sky-50 text-sky-700' },
  { name: 'Real Estate', hindi: 'रियल एस्टेट', icon: 'Building2', color: 'bg-emerald-50 text-emerald-700' },
  { name: 'Professional Services', hindi: 'प्रोफेशनल सेवाएँ', icon: 'BriefcaseBusiness', color: 'bg-violet-50 text-violet-700' },
  { name: 'Travel & Hospitality', hindi: 'ट्रैवल और हॉस्पिटैलिटी', icon: 'Plane', color: 'bg-cyan-50 text-cyan-700' },
  { name: 'Beauty & Wellness', hindi: 'ब्यूटी और वेलनेस', icon: 'Sparkles', color: 'bg-fuchsia-50 text-fuchsia-700' },
  { name: 'Finance & Legal', hindi: 'फाइनेंस और लीगल', icon: 'Scale', color: 'bg-lime-50 text-lime-700' },
  { name: 'Technology', hindi: 'टेक्नोलॉजी', icon: 'Laptop', color: 'bg-blue-50 text-blue-700' },
];

export const BIHAR_DISTRICTS = [
  'Araria', 'Arwal', 'Aurangabad', 'Banka', 'Begusarai', 'Bhagalpur', 'Bhojpur',
  'Buxar', 'Darbhanga', 'East Champaran', 'Gaya', 'Gopalganj', 'Jamui', 'Jehanabad',
  'Kaimur', 'Katihar', 'Khagaria', 'Kishanganj', 'Lakhisarai', 'Madhepura', 'Madhubani',
  'Munger', 'Muzaffarpur', 'Nalanda', 'Nawada', 'Patna', 'Purnia', 'Rohtas',
  'Saharsa', 'Samastipur', 'Saran', 'Sheikhpura', 'Sheohar', 'Sitamarhi', 'Siwan',
  'Supaul', 'Vaishali', 'West Champaran',
];
