const isAdmin = (user) => user?.profile === 'Admin_c';

const ownsBusiness = (record, user, store) => {
  return store.getAll('businesses_c').some((business) => {
    const relatedId = record.business_c?.Id ?? record.business_c;
    const ownerId = business.Owner?.Id ?? business.Owner;
    return String(business.Id) === String(relatedId) && String(ownerId) === String(user?.Id);
  });
};

export const select = (record, user, store) => {
  if (!user) return record.status_c === 'Approved';
  return isAdmin(user) || record.status_c === 'Approved' || ownsBusiness(record, user, store);
};

export const insert = (record, user) => !!user && (isAdmin(user) || user.profile === 'BusinessOwner_c');

export const update = (record, user, store) => {
  return !!user && (isAdmin(user) || ownsBusiness(record, user, store));
};

export const remove = (record, user, store) => {
  return !!user && (isAdmin(user) || ownsBusiness(record, user, store));
};
